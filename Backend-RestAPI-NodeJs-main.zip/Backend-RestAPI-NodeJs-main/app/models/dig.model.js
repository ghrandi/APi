const mongoose = require('mongoose');

const DigSchema = mongoose.Schema({
    type: String,
            
    idpanne: 
            String,
            
   
    description: String
	    
}, {
    timestamps: true
});

module.exports = mongoose.model('Dig', DigSchema);