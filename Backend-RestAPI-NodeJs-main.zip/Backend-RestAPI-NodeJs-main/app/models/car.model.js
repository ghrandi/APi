const mongoose = require('mongoose');

const CarSchema = mongoose.Schema({
    marque: String,
            
    modele: 
             String,
          
           

    annee: String,
    couleur: String,
    mission: String, 
     image: String
  
}, {
    timestamps: true
});

module.exports = mongoose.model('Car', CarSchema);