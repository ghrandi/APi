const mongoose = require('mongoose');

const PanneSchema = mongoose.Schema({
    type: String,
            
    idcar: 
            String,
            
   
    description: String,
	    digo: String
}, {
    timestamps: true
});

module.exports = mongoose.model('Panne', PanneSchema);