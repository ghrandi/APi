const mongoose = require('mongoose');

const DigoSchema = mongoose.Schema({
    type: String,
            
    idpanne: String,
   
    description: String
	
}, {
    timestamps: true
});

module.exports = mongoose.model('Digo', DigoSchema);