const mongoose = require('mongoose');

const AdminSchema = mongoose.Schema({
  
            
    email: {
            type: String,
            unique: [true, 'The email is unique']
           
    },
    password: String,
	photo:String
 
}, {
    timestamps: true
});

module.exports = mongoose.model('Admin', AdminSchema);