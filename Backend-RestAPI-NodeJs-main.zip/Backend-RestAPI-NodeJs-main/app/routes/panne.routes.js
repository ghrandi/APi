module.exports = (app) => {
    const pannes = require('../controllers/panne.controller.js');


    app.post('/pannes', pannes.create);

    
    app.get('/pannes', pannes.findAll);

   
    app.get('/pannes/:panneId', pannes.findOne);

    
    app.put('/pannes/:panneId', pannes.update);

    
    app.delete('/pannes/:panneId', pannes.delete);
}
