module.exports = (app) => {
    const digs = require('../controllers/dig.controller.js');


    app.post('/digs', digs.create);

    
    app.get('/digs', digs.findAll);

   
    app.get('/digs/:digId', digs.findOne);

    
    app.put('/digs/:digId', digs.update);

    
    app.delete('/digs/:digId', digs.delete);
}
