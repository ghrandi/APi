const Dig = require('../models/dig.model.js');

// Create and Save a new admin
exports.create = (req, res) => {
    // Validate request
    if(!req.body.type) {
        return res.status(400).send({
            message: "admin content can not be empty"
        });
    }

    // Create a admin
    const dig = new Dig({
        type: req.body.type || "Untitled admin",
        idpanne: req.body.idpanne,
        description: req.body.description, 
		
        
    });

    // Save admin in the database
    dig.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the admin."
        });
    });
};

// Retrieve and return all admin from the database.
exports.findAll = (req, res) => {
    Dig.find()
    .then(digs => {
        res.send(digs);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving admins."
        });
    });
};

// Find a single admin with a adminId
exports.findOne = (req, res) => {
    Dig.findById(req.params.digId)
    .then(dig => {
        if(!dig) {
            return res.status(404).send({
                message: "admin not found with id " + req.params.digId
            });            
        }
        res.send(dig);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "admin not found with id " + req.params.digId
            });                
        }
        return res.status(500).send({
            message: "Error retrieving admin with id " + req.params.digId
        });
    });
};

// Update a admin identified by the adminId in the request
exports.update = (req, res) => {
    // Validate Request
    if(!req.body.type) {
        return res.status(400).send({
            message: "admin content can not be empty"
        });
    }

    // Find admin and update it with the request body
  Dig.findByIdAndUpdate(req.params.digId, {
        type: req.body.type || "Untitled admin",
        idpanne: req.body.idpanne,
        description: req.body.description,

    }, {new: true})
    .then(dig => {
        if(!dig) {
            return res.status(404).send({
                message: "admin not found with id " + req.params.digId
            });
        }
        res.send(dig);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "admin not found with id " + req.params.digId
            });                
        }
        return res.status(500).send({
            message: "Error updating admin with id " + req.params.digId
        });
    });
};

// Delete a admin with the specified adminId in the request
exports.delete = (req, res) => {
    Dig.findByIdAndRemove(req.params.digId)
    .then(dig => {
        if(!dig) {
            return res.status(404).send({
                message: "admin not found with id " + req.params.digId
            });
        }
        res.send({message: "admin deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                message: "admin not found with id " + req.params.digId
            });                
        }
        return res.status(500).send({
            message: "Could not delete admin with id " + req.params.digId
        });
    });
};
