const Car = require('../models/car.model.js');

// Create and Save a new admin
exports.create = (req, res) => {
    // Validate request
    if(!req.body.marque) {
        return res.status(400).send({
            message: "admin content can not be empty"
        });
    }

    // Create a admin
    const car = new Car({
      marque: req.body.marque || "Untitled admin",
        modele: req.body.modele,
        annee: req.body.annee, 
        couleur : req.body.couleur,
        mission: req.body.mission,
        image: req.body.image,
       
    });

    // Save admin in the database
    car.save()
    .then(data => {
        res.send(data);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while creating the admin."
        });
    });
};

// Retrieve and return all admin from the database.
exports.findAll = (req, res) => {
    Car.find()
    .then(cars => {
        res.send(cars);
    }).catch(err => {
        res.status(500).send({
            message: err.message || "Some error occurred while retrieving admins."
        });
    });
};

// Find a single admin with a adminId
exports.findOne = (req, res) => {
    Car.findById(req.params.carId)
    .then(car => {
        if(!car) {
            return res.status(404).send({
                message: "admin not found with id " + req.params.carId
            });            
        }
        res.send(car);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "admin not found with id " + req.params.carId
            });                
        }
        return res.status(500).send({
            message: "Error retrieving admin with id " + req.params.carId
        });
    });
};

// Update a admin identified by the adminId in the request
exports.update = (req, res) => {
    // Validate Request
    if(!req.body.marque) {
        return res.status(400).send({
            message: "marque content can not be empty"
        });
    }

    // Find admin and update it with the request body
    Car.findByIdAndUpdate(req.params.carId, {
        marque: req.body.marque || "Untitled admin",
        modele: req.body.modele,
        annee: req.body.annee, 
        couleur : req.body.couleur,
        mission: req.body.mission,
       
        image: req.body.image
    }, {new: true})
    .then(car => {
        if(!car) {
            return res.status(404).send({
                message: "admin not found with id " + req.params.carId
            });
        }
        res.send(car);
    }).catch(err => {
        if(err.kind === 'ObjectId') {
            return res.status(404).send({
                message: "admin not found with id " + req.params.carId
            });                
        }
        return res.status(500).send({
            message: "Error updating admin with id " + req.params.carId
        });
    });
};

// Delete a admin with the specified adminId in the request
exports.delete = (req, res) => {
    Car.findByIdAndRemove(req.params.carId)
    .then(car => {
        if(!car) {
            return res.status(404).send({
                message: "admin not found with id " + req.params.carId
            });
        }
        res.send({message: "admin deleted successfully!"});
    }).catch(err => {
        if(err.kind === 'ObjectId' || err.name === 'NotFound') {
            return res.status(404).send({
                message: "admin not found with id " + req.params.carId
            });                
        }
        return res.status(500).send({
            message: "Could not delete admin with id " + req.params.carId
        });
    });
};
